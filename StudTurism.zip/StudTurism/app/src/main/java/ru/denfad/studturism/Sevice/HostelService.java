package ru.denfad.studturism.Sevice;

import java.util.ArrayList;
import java.util.List;

import ru.denfad.studturism.Model.Hostel;
import ru.denfad.studturism.R;

public class HostelService {

    private List<Hostel> hostels = new ArrayList<>();
    private static HostelService instance;

    private HostelService() {
        hostels.add(new Hostel("Арбат", "МГУ", "Москва", 1, 3, 1235, R.drawable.hostel_1));
        hostels.add(new Hostel("Общежитие №3", "АГУТ", "Ростов на дону", 1, 11, 600, R.drawable.hostel_2));
        hostels.add(new Hostel("Гостиница университета", "МоСаНИНА", "Можайск", 3, 7, 900, R.drawable.hostel_3));
        hostels.add(new Hostel("Общежитие центральное", "УДН", "Новосибирск", 1, 5, 78, R.drawable.hostel_4));
    }

    public static HostelService getInstance() {
        if(instance == null) instance = new HostelService();
        return instance;
    }

    public List<Hostel> getAll() {
        return hostels;
    }
}
